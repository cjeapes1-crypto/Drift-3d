# Drift Game Upgrade Plan

This starter includes a roadmap for:
- Multiplayer (Socket.IO)
- Circuit racing
- Leaderboards
- Drift scoring
- GitHub deployment

Suggested structure:
client/
server/
shared/
